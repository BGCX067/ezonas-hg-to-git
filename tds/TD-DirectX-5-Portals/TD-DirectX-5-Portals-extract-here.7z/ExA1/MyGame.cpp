#include "../Ngck_moteur/Ngck.h"
#include "map.h"

// -----------------------------------------------------------
void InitialiseGame()
{
	// Load map file 
	Map::GetMap()->LoadMapFile(0);
}
// -----------------------------------------------------------
void GameLoop()
{
	for (int x=0; x<MAP_WIDTH; x++)
	{
		for (int y=0; y<MAP_HEIGHT; y++)
		{
			if (Map::GetMap()->Get(x, y) == UNWALKABLE)
			{
				KSetDisplayColor(WHITE);
				KPrintSquare(x, y);
			}
			else if (Map::GetMap()->Get(x, y) == CAMERA)
			{
				KSetDisplayColor(RED);
				KPrintSquare(x, y);
			}
		}
	}
}
// -----------------------------------------------------------


