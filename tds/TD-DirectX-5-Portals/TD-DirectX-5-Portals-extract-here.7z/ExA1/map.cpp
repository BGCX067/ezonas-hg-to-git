#include "map.h"
#include<iostream>
#include<conio.h>
#include<fstream>
#include<iomanip>
using namespace std;

Map::Map()
{ 
	strcpy_s(szNomFichierMap[0], "map1.txt"); 
	strcpy_s(szNomFichierMap[1], "map2.txt"); 
	strcpy_s(szNomFichierMap[2], "map3.txt"); 
	CreateMapFile();
	InitialiseMap();
}

// map helper functions
int Map::Get( int x, int y )
{
	if( x < 0 ||
	    x >= MAP_WIDTH ||
		 y < 0 ||
		 y >= MAP_HEIGHT
	  )
	{
		return UNWALKABLE;	 
	}

	return map[x][y];
}

// map helper functions
bool Map::Set( int x, int y, int _value )
{
	if( x < 0 ||
	    x >= MAP_WIDTH ||
		 y < 0 ||
		 y >= MAP_HEIGHT
	  )
	{
		return false;	 
	}

	map[x][y] = _value;

	return true;
}

void Map::InitialiseMap()
{
	for (int x=0; x<MAP_WIDTH; x++)
	{
		for (int y=0; y<MAP_HEIGHT; y++)
		{
			map[x][y] = WALKABLE;
		}
	}
}

bool Map::CreateMapFile()
{
	bool bCreateFile = false;

	//Test fichier existe
	ifstream isFile;
	isFile.open(szNomFichierMap[0]);
	if (isFile.fail())
	{
		bCreateFile = true;
	}
	isFile.close();

	if (bCreateFile)
	{
		ofstream osFile;

		osFile.open(szNomFichierMap[0]);
		if (osFile.fail())
		{
			cout<<"probleme ouverture fichier"<<endl;
			return false;
		}
		else
		{
			osFile <<  "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" << endl;
			osFile <<  "x1111111111111111111111111111x" << endl;
			osFile <<  "x1111111111111111111111111111x" << endl;
			osFile <<  "x1111111111111111111111111111x" << endl;
			osFile <<  "xxxxxxxxxxxxxxxxxpxxxxxxxxxxxx" << endl;
			osFile <<  "x22222222222x3333333333333333x" << endl;
			osFile <<  "x22222222222x3333333333333333x" << endl;
			osFile <<  "x22222222222x3333333333333333x" << endl;
			osFile <<  "xxxxxxppxxxxxxxxxppxxxxxxxxxxx" << endl;
			osFile <<  "x4444444444444444444444444444x" << endl;
			osFile <<  "x4444444444444444444444444444x" << endl;
			osFile <<  "x4444444444444444444444444444x" << endl;
			osFile <<  "xxxxxxppppxxxxxxppppxxxxxxxxxx" << endl;
			osFile <<  "555555555555555555555555555555" << endl;
			osFile <<  "555555555555555555555555555555" << endl;
			osFile <<  "555555555555555555555555555555" << endl;
			osFile <<  "555555555555555555555555555555" << endl;
			osFile <<  "555555555555555555555555555555" << endl;
			osFile <<  "555555555555555555555555555555" << endl;
			osFile <<  "5e5555555555555555555555555555" << endl;
		}
		osFile.close();
		osFile.open(szNomFichierMap[1]);
		if (osFile.fail())
		{
			cout<<"probleme ouverture fichier"<<endl;
			return false;
		}
		else
		{
			osFile <<  "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" << endl;
			osFile <<  "x1111111111111111111111111111x" << endl;
			osFile <<  "x1111111111111111111111111111x" << endl;
			osFile <<  "x1111111111111111111111111111x" << endl;
			osFile <<  "xxxxxxxxxxxxxxxxxpxxxxxxxxxxxx" << endl;
			osFile <<  "x22222222222x3333333333333333x" << endl;
			osFile <<  "x22222222222x3333333333333333x" << endl;
			osFile <<  "x22222222222x3333333333333333x" << endl;
			osFile <<  "xxxxxxppxxxxxxxxxppxxxxxxxxxxx" << endl;
			osFile <<  "x4444444444444444444444444444x" << endl;
			osFile <<  "x4444444444444444444444444444x" << endl;
			osFile <<  "x4444444444444444444444444444x" << endl;
			osFile <<  "xxxxxxppppxxxxxxppppxxxxxxxxxx" << endl;
			osFile <<  "555555555555555555555555555555" << endl;
			osFile <<  "555555555555555555555555555555" << endl;
			osFile <<  "555555555555555555555555555555" << endl;
			osFile <<  "555555555555555555555555555555" << endl;
			osFile <<  "555555555555555555555555555555" << endl;
			osFile <<  "555555555555555555555555555555" << endl;
			osFile <<  "5555555e5555555555555555555555" << endl;
		}
		osFile.close();

		osFile.open(szNomFichierMap[2]);
		if (osFile.fail())
		{
			cout<<"probleme ouverture fichier"<<endl;
			return false;
		}
		else
		{
			osFile <<  "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" << endl;
			osFile <<  "x1111111111111111111111111111x" << endl;
			osFile <<  "x1111111111111111111111111111x" << endl;
			osFile <<  "x1111111111111111111111111111x" << endl;
			osFile <<  "xxxxxxxxxxxxxxxxxpxxxxxxxxxxxx" << endl;
			osFile <<  "x22222222222x3333333333333333x" << endl;
			osFile <<  "x22222222222x3333333333333333x" << endl;
			osFile <<  "x22222222222x3333333333333333x" << endl;
			osFile <<  "xxxxxxppxxxxxxxxxppxxxxxxxxxxx" << endl;
			osFile <<  "x4444444444444444444444444444x" << endl;
			osFile <<  "x4444444444444444444444444444x" << endl;
			osFile <<  "x4444444444444444444444444444x" << endl;
			osFile <<  "xxxxxxppppxxxxxxppppxxxxxxxxxx" << endl;
			osFile <<  "555555555555555555555555555555" << endl;
			osFile <<  "555555555555555555555555555555" << endl;
			osFile <<  "555555555555555555555555555555" << endl;
			osFile <<  "555555555555555555555555555555" << endl;
			osFile <<  "555555555555555555555555555555" << endl;
			osFile <<  "555555555555555555555555555555" << endl;
			osFile <<  "55555555555555555e555555555555" << endl;
		}
		osFile.close();
	}
	return true;
} 
// ---------------------------------------------------------------------
bool Map::LoadMapFile(int _i)
{
	ifstream isFile;
	char cChar;

	isFile.open(szNomFichierMap[_i]);
	if (isFile.fail())
	{
		cout<<"probleme ouverture fichier"<<endl;
		return false;
	}
	else
	{
		for (int i=0; i<MAP_HEIGHT; i++)
			for (int j=0; j<MAP_WIDTH; j++)
			{
				isFile >> cChar;
				if (cChar == 'x')
				{
					map[j][i] = UNWALKABLE;
				}
				else if (cChar == '1')
				{
					map[j][i] = Z1;
				}
				else if (cChar == '2')
				{
					map[j][i] = Z2;
				}
				else if (cChar == '3')
				{
					map[j][i] = Z3;
				}
				else if (cChar == '4')
				{
					map[j][i] = Z4;
				}
				else if (cChar == 'p')
				{
					map[j][i] = PORTAL;
				}
				else if (cChar == 'e')
				{
					map[j][i] = CAMERA;
				}
				else
				{
					map[j][i] = Z5;
				}

			}
	}
	isFile.close();
	return true;
} 