// The world map
#ifndef MAP_H
#define MAP_H

const int MAP_WIDTH = 30;
const int MAP_HEIGHT = 20;
const int WALKABLE = 6, 
PORTAL = 7, 
CAMERA = 8, 
Z1 = 1, 
Z2 = 2, 
Z3 = 3, 
Z4 = 4, 
Z5 = 5, 
UNWALKABLE = 9;	// walkability array constants

class Map
{
private:
	char szNomFichierMap[3][80];
	int map[ MAP_WIDTH ][ MAP_HEIGHT ];

	Map();

public:

	static Map* GetMap()
	{
	   static Map instanceUnique;
	   return &instanceUnique;
	}

	// map helper functions
	int Get( int x, int y );
	bool Set( int x, int y, int _value );
	void InitialiseMap();
	bool CreateMapFile();
	bool LoadMapFile(int _i);
};
#endif