
#include <stdlib.h> // Pour le rand()
#include <string.h> // Pour le sprintf
#include <stdio.h>  

// -----------------------------------------------------
// TYPES
// -----------------------------------------------------

enum eColors
{
  WHITE=0,
  RED=1,
  GREEN=2,
  BLUE=3,
  YELLOW=4,
  PURPLE=5,
  CYAN=6,
  MAXCOLOR=7
};

// -----------------------------------------------------
// FUNCTIONS
// -----------------------------------------------------


void KPrintSquare(int x, int y);
void KPrintBall(int x, int y);
void KPrintBar(int x, int y);
void KSetDisplayColor(int colorId);
void KPrintString(char* string, int x, int y);
int  KGetSpace(void);
int  KGetLeft(void);
int  KGetUp(void);
int  KGetRight(void);
int  KGetDown(void);

// -----------------------------------------------------

