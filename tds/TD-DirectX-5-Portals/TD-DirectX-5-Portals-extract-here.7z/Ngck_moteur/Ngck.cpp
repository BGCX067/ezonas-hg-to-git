
#include "./SDL/SDL.h"
#include "./SDL/SDL_image.h"
#include "BFont.h"

#include "Ngck.h"

extern void InitialiseGame(void);
extern void GameLoop(void);


SDL_Surface* SpriteSquare    = NULL;
SDL_Surface* SpriteCircle    = NULL;
SDL_Surface* SpriteBar       = NULL;

SDL_Surface* SpriteFond      = NULL;

SDL_Surface* screen = NULL;

int done = 0;   


// Style Graphique. 0=Simple
int GfxStyle;

long time1, time2;

struct caseecran
{
  int value;
  int colorId;
};

caseecran  ecran[30][20]; // Memoire de l'ecran. 0=Rien 1=Carré 2=Rond 3=Barre
bool  IsRight;
bool  IsLeft;
bool  IsUp;
bool  IsDown;
bool  IsSpace;


BFont_Info *MyFont = NULL;

int actualcolor;

// -------------------------------------------------------------------
// Name :
// -------------------------------------------------------------------
void KPrintSquare(int x, int y)
{
  // Test si on est dans l'ecran
  if ( (x<0) || (x>=30) || (y<0) || (y>=20) )
    return;

  ecran[x][y].value=1;
  ecran[x][y].colorId=actualcolor;
}

// -------------------------------------------------------------------
// Name :
// -------------------------------------------------------------------
void KPrintBall(int x, int y)
{
  // Test si on est dans l'ecran
  if ( (x<0) || (x>=30) || (y<0) || (y>=20) )
    return;

  ecran[x][y].value=2;
  ecran[x][y].colorId=actualcolor;
}

// -------------------------------------------------------------------
// Name :
// -------------------------------------------------------------------
void KPrintBar(int x, int y)
{
  // Test si on est dans l'ecran
  if ( (x<0) || (x>=30) || (y<0) || (y>=20) )
    return;

  ecran[x][y].value=3;
  ecran[x][y].colorId=actualcolor;
}

SDL_Color GetColorFromId(int colorid)
{
  SDL_Color color;
  color.r=254;
  color.g=254;
  color.b=254;
  if (colorid==WHITE)  { color.r=254; color.g=254; color.b=254; }
  if (colorid==RED)    { color.r=254; color.g=0;   color.b=0; }
  if (colorid==GREEN)  { color.r=0;   color.g=254; color.b=0; }
  if (colorid==BLUE)   { color.r=0;   color.g=0;   color.b=254; }
  if (colorid==YELLOW) { color.r=254; color.g=254; color.b=0; }
  if (colorid==PURPLE) { color.r=254; color.g=0;   color.b=254; }
  if (colorid==CYAN)   { color.r=0;   color.g=254; color.b=254; }
  //SpriteSquare->SetGlobalColor(color);
  return color;
}

void SetGlobalColor(SDL_Surface* Sprite, SDL_Color color)
{
	if (Sprite==NULL)
		return;

   Sprite->format->Rmask = color.r << Sprite->format->Rshift;
   Sprite->format->Gmask = color.g << Sprite->format->Gshift;
   Sprite->format->Bmask = color.b << Sprite->format->Bshift;
}

// -------------------------------------------------------------------
// Name :
// -------------------------------------------------------------------
void AfficheEcran()
{
 int i,j;
 char montexte[2];
 montexte[1]=0;
 SDL_Color color;
 SDL_Rect rect;
/*
 SpriteFond->SetCurrentSizeXY(800, 600);
 SpriteFond->SetTiled(false);
 SpriteFond->Draw(0,0); // Affiche decor
*/
 rect.x = 0; rect.y = 0;
 SDL_BlitSurface(SpriteFond, NULL, screen, &rect);



 for (i=0; i<30; i++)
 {
    for (j=0; j<20; j++)
    {
      color=GetColorFromId(ecran[i][j].colorId);

      if (ecran[i][j].value==1) { SetGlobalColor(SpriteSquare, color); rect.x = i*16; rect.y = j*16;
                                  SDL_BlitSurface(SpriteSquare, NULL, screen, &rect); }
      if (ecran[i][j].value==2) { SetGlobalColor(SpriteCircle, color); rect.x = i*16; rect.y = j*16;
                                  SDL_BlitSurface(SpriteCircle, NULL, screen, &rect); }
      if (ecran[i][j].value==3) { SetGlobalColor(SpriteBar, color);  rect.x = i*16; rect.y = j*16;      
                                  SDL_BlitSurface(SpriteBar, NULL, screen, &rect); }
      if (ecran[i][j].value>' ')
      {
        montexte[0]=ecran[i][j].value;
        
        /*MyFont->SetColor(color);*/
        /* MyFont->Draw(160+i*16,140+j*16, montexte); */
        SetGlobalColor(MyFont->Surface, color);
        PutString (screen,i*16 , j*16 -8 ,montexte ); // -8 car fonte trop grande
      } 
    }
 }
}

// -------------------------------------------------------------------
// Name :
// -------------------------------------------------------------------
void EffaceEcran()
{
 int i,j;
 for (i=0; i<30; i++)
 {
    for (j=0; j<20; j++)
    {
      ecran[i][j].value=0;
      ecran[i][j].colorId=0;
    }
 }
}

// -------------------------------------------------------------------
// Name :
// -------------------------------------------------------------------
void EffaceCommandes()
{
  IsRight=0;
  IsLeft=0;
  IsUp=0;
  IsDown=0;
  IsSpace=0;
}

// -------------------------------------------------------------------
// Name :
// -------------------------------------------------------------------
void UpdateCommandes()
{
    SDL_Event event;                  /* Evenements de l'application  */
    
		/*  Gestions des messages Systeme  */
		while ( SDL_PollEvent(&event) ) {
			switch (event.type) {
				case SDL_KEYDOWN:
                                   switch( event.key.keysym.sym )
                                    {
  			               case SDLK_ESCAPE:
                     		               done = 1;
				               break;

		   		       case SDLK_SPACE:
                                               IsSpace = 1;
                                               break;
		   		       case SDLK_LEFT:
                                               IsLeft = 1;
                                               break;
		   		       case SDLK_RIGHT:
                                               IsRight = 1;
                                               break;
		   		       case SDLK_DOWN:
                                               IsDown = 1;
                                               break;
		   		       case SDLK_UP:
                                               IsUp = 1;
                                               break;
         
                                       default:
                                               break;
	                            }
                                   break;
/*
				case SDL_KEYUP:
                                   switch( event.key.keysym.sym )
                                    {
		   		       case SDLK_SPACE:
                                               IsSpace = 0;
                                               break;
		   		       case SDLK_LEFT:
                                               IsLeft = 0;
                                               break;
		   		       case SDLK_RIGHT:
                                               IsRight = 0;
                                               break;
		   		       case SDLK_DOWN:
                                               IsDown = 0;
                                               break;
		   		       case SDLK_UP:
                                               IsUp = 0;
                                               break;
         
                                       default:
                                               break;
	                            }
                                   break;
*/
        			case SDL_QUIT:
                                   done = 1;
                                   break;
     
			        default:
				  break;
			}
		}

}

// -------------------------------------------------------------------
// Name :
// -------------------------------------------------------------------
int KGetLeft(void)
{
  return IsLeft;
}

// -------------------------------------------------------------------
// Name :
// -------------------------------------------------------------------
int KGetUp(void)
{
  return IsUp;
}

// -------------------------------------------------------------------
// Name :
// -------------------------------------------------------------------
int KGetRight(void)
{
  return IsRight;
}

// -------------------------------------------------------------------
// Name :
// -------------------------------------------------------------------
int KGetDown(void)
{
  return IsDown;
}

// -------------------------------------------------------------------
// Name :
// -------------------------------------------------------------------
int KGetSpace(void)
{
  return IsSpace;
}

// -------------------------------------------------------------------
// Name :
// -------------------------------------------------------------------
void KSetDisplayColor(int colorid)
{
    actualcolor=colorid;
}

// -----------------------------------------------------------------
// -----------------------------------------------------------------
void KPrintString(char* string, int x, int y)
{
  int i;
  int lenght;
  lenght=(int)strlen(string);
  for (i=0; i<lenght; i++)
  {
    if ( (x+i<0) || (x+i>=30) || (y<0) || (y>=20) )
      continue;
    else
    {
      ecran[x+i][y].value=string[i]; // Copie lettre dans ecran local
      ecran[x+i][y].colorId=actualcolor;
    }
  }
  
}


// ---------------------------------------------------------------------------------------------

SDL_Surface* LOAD_IMG_AND_DisplayFormat(const char *filename)
 {
   SDL_Surface *Surftemp1, *Surftemp2;     /*  Surfaces temporaires  */

   Surftemp1 = IMG_Load(filename); /* Charge l'image */
   Surftemp2 = SDL_DisplayFormat(Surftemp1); 
   
   SDL_FreeSurface(Surftemp1);

     /* Renvoie l'image chargee dans le format de couleurs de l'ecran */
   return Surftemp2;
 }
 
void	NGCKInit()
{
  time1 = time2 = SDL_GetTicks();
  
  GfxStyle=0; // Style graphique par defaut (simple)
  InitialiseGame();
  
  if (GfxStyle==0)
  {  
    SpriteSquare = LOAD_IMG_AND_DisplayFormat("datas/Square1.png");
    SpriteCircle = LOAD_IMG_AND_DisplayFormat("datas/Circle1.png");
    SpriteBar    = LOAD_IMG_AND_DisplayFormat("datas/Bar1.png");
    SpriteFond   = LOAD_IMG_AND_DisplayFormat("datas/Fond1.png");
  }
  
  MyFont = LoadFont ("datas/Font1.png");
  SetCurrentFont (MyFont);

  actualcolor=WHITE;
}


// ---------------------------------------------------------------------------------------------
bool	NGCKGameLoop()
{
  time1 = SDL_GetTicks();
  
  if ((time1-time2)<16*8) // On attend 8 trames
  {
    UpdateCommandes(); 
    AfficheEcran();
    return true;
  }
 
  time2=time1;

  EffaceEcran();
  //UpdateCommandes();

  GameLoop();

  AfficheEcran();
  EffaceCommandes();

  return true;
}


// ---------------------------------------------------------------------------------------------
void	NGCKUnInit()
{
  SDL_FreeSurface(SpriteSquare);
  SDL_FreeSurface(SpriteCircle);
  SDL_FreeSurface(SpriteBar);
  SDL_FreeSurface(SpriteFond);
  FreeFont(MyFont);
}


int main(int argc, char *argv[])
{
      /* Initialize SDL */
	if ( SDL_Init(SDL_INIT_VIDEO) < 0 ) {
		fprintf(stderr, "Couldn't initialize SDL: %s\n",SDL_GetError());
		exit(1);
	}
	atexit(SDL_Quit);

	if ( (screen=SDL_SetVideoMode(480,320, 32, SDL_HWSURFACE /*| SDL_FULLSCREEN*/ |SDL_DOUBLEBUF)) == NULL )
	{
		fprintf(stderr, "Couldn't set 480x320x32 video mode: %s\n", SDL_GetError());
		exit(2);
	}

    /* On desactive le curseur de la souris */  
	SDL_ShowCursor(SDL_DISABLE);
	
        NGCKInit();
        
	while ( !done ) {
        
          NGCKGameLoop();
          
          SDL_Flip(screen);
                  
	}

  NGCKUnInit();
 
  return 0;
}
