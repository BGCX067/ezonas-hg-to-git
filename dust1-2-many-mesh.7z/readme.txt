These are just dust maps I grabbed on the 3d ware house and converted with some rb script I found online.

I used sketchup 8, and there were different sketchup file versions, from6 to 7 I guess.